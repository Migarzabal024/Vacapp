
  # VacApp 2.0 IA

  This is a code bundle for VacApp 2.0 IA. The original project is available at https://www.figma.com/design/OV5C8BqLGwqSTYWEVF7GPp/VacApp-2.0-IA.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  