# 📱 VacaApp - Guía de Exportación a Figma

Esta guía te ayudará a exportar las 6 pantallas de VacaApp desde React a Figma como frames individuales editables.

## 🎯 Pantallas Disponibles

1. **Splash Screen** - Pantalla de bienvenida con animación
2. **Onboarding** - 3 slides con genética, KYC y cierre QR
3. **Login** - Inicio de sesión con email/password
4. **Register** - Registro en 3 pasos (datos personales, fiscales, seguridad)
5. **Home** - Pantalla principal con carrusel y grid de animales
6. **Animal Detail** - Detalle completo con genética y reserva QR

## 🚀 Método 1: Galería de Exportación (Recomendado)

### Paso 1: Accede a la galería
```bash
# Asegúrate de que el servidor esté corriendo
npm run dev
# O si usas otro comando de inicio
```

### Paso 2: Navega a la galería
Abre tu navegador y ve a: `http://localhost:PUERTO/screens-gallery`

Esta página muestra las 6 pantallas en un grid, cada una en un contenedor de 390x844px (iPhone 14 Pro).

### Paso 3: Exporta a Figma usando html.to.design

1. **Instala el plugin en Figma:**
   - Abre Figma
   - Ve a Plugins → Browse plugins in Community
   - Busca "html.to.design" o "HTML to Figma"
   - Instala el plugin

2. **Exporta las pantallas:**
   - En Figma, ejecuta el plugin instalado
   - Copia la URL completa de la página de galería
   - Pégala en el plugin
   - El plugin creará automáticamente 6 frames individuales

### Paso 4: Organiza los frames
Los frames se importarán con los nombres:
- `01-Splash-Screen`
- `02-Onboarding-Screen`
- `03-Login-Screen`
- `04-Register-Screen`
- `05-Home-Screen`
- `06-Animal-Detail-Screen`

## 🖼️ Método 2: Captura de Pantalla

Si prefieres un control más manual:

1. **Abre cada ruta individualmente:**
   - `/` - Splash
   - `/onboarding` - Onboarding
   - `/login` - Login
   - `/register` - Register
   - `/home` - Home
   - `/animal/1` - Detail

2. **Toma screenshots:**
   - Usa las DevTools del navegador
   - Configura el viewport a 390x844px
   - Toma capturas de cada pantalla

3. **Importa a Figma:**
   - Arrastra las imágenes a Figma
   - Crea frames de 390x844px
   - Coloca cada imagen dentro de su frame

## 🎨 Método 3: Inspección y Recreación Manual

Para máxima fidelidad y editabilidad:

1. **Usa Figma Dev Mode:**
   - Inspecciona cada elemento en el navegador
   - Copia las medidas, espaciados y colores exactos
   - Recrea los componentes en Figma

2. **Datos de diseño importantes:**

### Paleta de Colores
```
Primary Dark:   #0A1E16
Primary Mid:    #1E3D2B
Accent Green:   #4EBA2E
Muted Gray:     #868C5A
Background:     #F2F2F2
White:          #FFFFFF
```

### Tipografías
- **Poppins** (700-800): Títulos, nombres de marca, CTAs
- **Inter** (400-600): Cuerpo de texto, labels, botones secundarios

### Dimensiones Mobile
- **Ancho:** 390px (iPhone 14 Pro)
- **Alto:** 844px
- **Border radius principal:** 12px-20px
- **Espaciado grid:** 16px horizontal, 12px vertical

### Componentes clave
- **Botones principales:** h-14 (56px), rounded-2xl, gradient verde
- **Input fields:** h-14, rounded-xl, bg #F2F2F2
- **Cards de animales:** rounded-2xl, imagen 176px alto
- **Bottom nav:** 5 items, icon 22px

## 🔧 Método 4: Plugin de Código a Diseño

Si trabajas con código regularmente:

1. **Figma Code Connect:**
   - Configura Code Connect en el proyecto
   - Vincula componentes React con Figma
   - Sincroniza cambios automáticamente

2. **Anima o Framer:**
   - Exporta componentes React a estas herramientas
   - Luego importa a Figma desde allí

## 📦 Archivos de Referencia

- **Código fuente:** `src/app/components/`
- **Estilos:** `src/styles/theme.css`
- **Galería:** `src/app/screens-export/ScreensGallery.tsx`
- **Rutas:** `src/app/routes.ts`

## 🎯 Tips para Mejores Resultados

1. **Desactiva animaciones temporalmente** si causan problemas en la exportación
2. **Usa modo claro/oscuro** según tu preferencia de diseño
3. **Verifica las fuentes** estén instaladas en Figma (Poppins, Inter)
4. **Convierte las imágenes** de Unsplash a placeholders si no tienes acceso
5. **Agrupa elementos** lógicamente después de importar

## 🐛 Problemas Comunes

### Las animaciones no se capturan
- Usa la galería estática en `/screens-gallery`
- Las animaciones no se exportan, solo estados finales

### Los gradientes no se ven bien
- Recrea los gradientes manualmente en Figma:
  - Splash/Login header: `linear-gradient(160deg, #0A1E16 0%, #1E3D2B 100%)`
  - Botones CTA: `linear-gradient(135deg, #4EBA2E, #1E3D2B)`

### Las fuentes no coinciden
- Descarga e instala Google Fonts:
  - [Poppins](https://fonts.google.com/specimen/Poppins)
  - [Inter](https://fonts.google.com/specimen/Inter)

### Las imágenes no cargan
- Reemplaza las URLs de Unsplash con placeholders
- O descarga las imágenes y úsalas localmente

## 💡 Siguiente Paso

Una vez que tengas los frames en Figma:

1. **Organiza en páginas:**
   - "Screens" - Las 6 pantallas
   - "Components" - Componentes reusables
   - "Styles" - Colores, tipografías, efectos

2. **Crea un Design System:**
   - Tokens de color
   - Estilos de texto
   - Componentes base (botones, inputs, cards)
   - Iconos (Lucide React equivalentes)

3. **Documenta las interacciones:**
   - Flujos de usuario
   - Estados de componentes (hover, active, disabled)
   - Variantes de pantallas (diferentes steps)

## 📞 Soporte

Si tienes problemas con la exportación, revisa:
- La consola del navegador por errores
- Que todas las dependencias estén instaladas
- Que el servidor de desarrollo esté corriendo correctamente

---

**Paleta completa para Figma Styles:**

| Nombre           | Código  |
|------------------|---------|
| Primary/Dark     | #0A1E16 |
| Primary/Mid      | #1E3D2B |
| Accent/Green     | #4EBA2E |
| Neutral/Muted    | #868C5A |
| Background/Light | #F2F2F2 |
| Background/Input | #E6F1E6 |
| White            | #FFFFFF |

**Tipografías para Figma:**
- Poppins Bold (700) - 42px, 26px, 22px, 18px
- Poppins ExtraBold (800) - 42px (logo)
- Inter SemiBold (600) - 16px, 15px, 14px
- Inter Medium (500) - 14px, 13px
- Inter Regular (400) - 15px, 14px, 13px, 12px
