# VacaApp - Exportación a Figma

## 🎯 Acceso Rápido

Inicia el servidor de desarrollo y visita cualquiera de estas rutas:

### 🌟 Recomendado: Índice de Exportación
```
http://localhost:PUERTO/figma-export
```

### 📱 Opciones disponibles:

1. **Galería Completa** → `/screens-gallery`
   - Las 6 pantallas en un solo grid
   - Ideal para plugin html.to.design

2. **Pantallas Individuales** → `/export`
   - Navega entre pantallas
   - Rutas: `/export/splash`, `/export/onboarding`, etc.

3. **Guía Completa** → Lee `FIGMA_EXPORT_GUIDE.md`

## 📋 Pantallas Exportables

| Pantalla | Ruta | Descripción |
|----------|------|-------------|
| 🎨 Splash | `/export/splash` | Bienvenida con logo animado |
| 📖 Onboarding | `/export/onboarding` | 3 slides educativos |
| 🔐 Login | `/export/login` | Inicio de sesión |
| 📝 Register | `/export/register` | Registro en 3 pasos |
| 🏠 Home | `/export/home` | Feed con carrusel y grid |
| 🐄 Detail | `/export/detail` | Detalle completo del animal |

## 🎨 Paleta de Colores

```css
--primary-dark:    #0A1E16
--primary-mid:     #1E3D2B
--accent-green:    #4EBA2E
--muted-gray:      #868C5A
--background:      #F2F2F2
--input-bg:        #E6F1E6
```

## ✍️ Tipografías

- **Poppins** (Bold 700-800): Títulos, logos
- **Inter** (Regular-SemiBold 400-600): UI, cuerpo

## 📐 Dimensiones

- **Mobile Frame:** 390×844px (iPhone 14 Pro)
- **Botones:** 56px altura
- **Espaciado:** 16px, 12px, 8px
- **Border radius:** 12px, 16px, 20px

## 🚀 Método Rápido (html.to.design)

1. Inicia servidor: `npm run dev`
2. Visita: `/screens-gallery`
3. En Figma → Plugin "html.to.design"
4. Pega la URL → ¡Listo!

---

Para instrucciones detalladas, lee `FIGMA_EXPORT_GUIDE.md` o `RESUMEN_EXPORTACION.md`
