import { RouterProvider } from "react-router";
import { router } from "./routes";

export default function App() {
  // Check if we're on an export route (full viewport)
  const isExportRoute = window.location.pathname.startsWith("/screens-gallery") ||
                        window.location.pathname.startsWith("/export") ||
                        window.location.pathname === "/figma-export";

  if (isExportRoute) {
    return <RouterProvider router={router} />;
  }

  return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "linear-gradient(135deg, #0A1E16 0%, #1E3D2B 100%)" }}>
      <div
        className="relative overflow-hidden bg-white shadow-2xl"
        style={{
          width: "100%",
          maxWidth: "390px",
          height: "100vh",
          maxHeight: "844px",
          fontFamily: "'Inter', sans-serif",
        }}
      >
        <RouterProvider router={router} />
      </div>
    </div>
  );
}
