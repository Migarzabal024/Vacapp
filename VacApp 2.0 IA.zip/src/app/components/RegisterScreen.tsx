import { useState } from "react";
import { useNavigate } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { User, Mail, CreditCard, Building2, Eye, EyeOff, Lock, ChevronLeft, Check } from "lucide-react";

type FormData = {
  nombre: string;
  email: string;
  dni: string;
  cuit: string;
  rol: "productor" | "admin";
  password: string;
  confirm: string;
};

const STEPS = ["Datos personales", "Datos fiscales", "Seguridad"];

function ProgressBar({ step }: { step: number }) {
  return (
    <div className="flex gap-2 w-full">
      {STEPS.map((label, i) => (
        <div key={i} className="flex-1 flex flex-col items-center gap-1">
          <div
            className="w-full h-1.5 rounded-full transition-all duration-500"
            style={{ background: i <= step ? "#4EBA2E" : "#E6F1E6" }}
          />
          <span className="text-xs" style={{ color: i <= step ? "#4EBA2E" : "#868C5A", fontWeight: i === step ? 600 : 400 }}>
            {label}
          </span>
        </div>
      ))}
    </div>
  );
}

function InputField({
  label, icon, type = "text", placeholder, value, onChange, right,
}: {
  label: string;
  icon: React.ReactNode;
  type?: string;
  placeholder: string;
  value: string;
  onChange: (v: string) => void;
  right?: React.ReactNode;
}) {
  return (
    <div>
      <label className="text-xs font-semibold mb-1.5 block" style={{ color: "#1E3D2B" }}>{label}</label>
      <div
        className="flex items-center gap-3 rounded-xl px-4 py-3.5 border"
        style={{ background: "#F2F2F2", borderColor: value ? "#4EBA2E" : "transparent" }}
      >
        <div style={{ color: "#868C5A" }}>{icon}</div>
        <input
          type={type}
          placeholder={placeholder}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="flex-1 bg-transparent outline-none text-sm"
          style={{ color: "#1A1A1A" }}
        />
        {right}
      </div>
    </div>
  );
}

export function RegisterScreen() {
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [showPass, setShowPass] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [done, setDone] = useState(false);
  const [form, setForm] = useState<FormData>({
    nombre: "",
    email: "",
    dni: "",
    cuit: "",
    rol: "productor",
    password: "",
    confirm: "",
  });

  const set = (field: keyof FormData) => (value: string) =>
    setForm((f) => ({ ...f, [field]: value }));

  const next = async () => {
    if (step < 2) {
      setStep((s) => s + 1);
    } else {
      setLoading(true);
      await new Promise((r) => setTimeout(r, 1500));
      setLoading(false);
      setDone(true);
      setTimeout(() => navigate("/home"), 2000);
    }
  };

  if (done) {
    return (
      <div
        className="flex flex-col items-center justify-center w-full h-full gap-5"
        style={{ background: "linear-gradient(160deg, #0A1E16 0%, #1E3D2B 100%)" }}
      >
        <motion.div
          className="w-24 h-24 rounded-full flex items-center justify-center shadow-xl"
          style={{ background: "#4EBA2E" }}
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 200, damping: 14 }}
        >
          <Check size={48} className="text-white" strokeWidth={3} />
        </motion.div>
        <motion.div
          className="flex flex-col items-center gap-2"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <h2 className="text-white text-xl font-bold" style={{ fontFamily: "'Poppins', sans-serif" }}>
            ¡Bienvenido a VacApp!
          </h2>
          <p className="text-sm text-center px-8" style={{ color: "rgba(255,255,255,0.6)" }}>
            Tu cuenta fue creada. Verificá tu email para activar el KYC.
          </p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="flex flex-col w-full h-full bg-white overflow-y-auto">
      {/* Header */}
      <div
        className="flex flex-col gap-4 px-6 pt-14 pb-8"
        style={{ background: "linear-gradient(160deg, #0A1E16 0%, #1E3D2B 100%)" }}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={() => (step === 0 ? navigate("/login") : setStep((s) => s - 1))}
            className="w-9 h-9 rounded-xl flex items-center justify-center"
            style={{ background: "rgba(255,255,255,0.1)" }}
          >
            <ChevronLeft size={20} className="text-white" />
          </button>
          <div>
            <h2 className="text-white font-bold" style={{ fontFamily: "'Poppins', sans-serif", fontSize: "18px" }}>
              Crear cuenta
            </h2>
            <p className="text-xs" style={{ color: "#868C5A" }}>Paso {step + 1} de 3</p>
          </div>
        </div>
        <ProgressBar step={step} />
      </div>

      {/* Form body */}
      <div className="flex-1 bg-white rounded-t-3xl -mt-4 px-6 pt-7 pb-8">
        <AnimatePresence mode="wait">
          {step === 0 && (
            <motion.div
              key="step0"
              className="flex flex-col gap-4"
              initial={{ opacity: 0, x: 40 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -40 }}
              transition={{ duration: 0.3 }}
            >
              <h3 className="font-bold mb-1" style={{ color: "#0A1E16", fontFamily: "'Poppins', sans-serif", fontSize: "18px" }}>
                Tus datos personales
              </h3>
              <InputField
                label="Nombre completo"
                icon={<User size={18} />}
                placeholder="Ej: Juan María González"
                value={form.nombre}
                onChange={set("nombre")}
              />
              <InputField
                label="Correo electrónico"
                icon={<Mail size={18} />}
                type="email"
                placeholder="tu@email.com"
                value={form.email}
                onChange={set("email")}
              />
            </motion.div>
          )}

          {step === 1 && (
            <motion.div
              key="step1"
              className="flex flex-col gap-4"
              initial={{ opacity: 0, x: 40 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -40 }}
              transition={{ duration: 0.3 }}
            >
              <h3 className="font-bold mb-1" style={{ color: "#0A1E16", fontFamily: "'Poppins', sans-serif", fontSize: "18px" }}>
                Datos fiscales
              </h3>
              <InputField
                label="DNI"
                icon={<CreditCard size={18} />}
                placeholder="Ej: 35.123.456"
                value={form.dni}
                onChange={set("dni")}
              />
              <InputField
                label="CUIT / CUIL"
                icon={<Building2 size={18} />}
                placeholder="Ej: 20-35123456-7"
                value={form.cuit}
                onChange={set("cuit")}
              />
              {/* Role selector */}
              <div>
                <label className="text-xs font-semibold mb-2 block" style={{ color: "#1E3D2B" }}>
                  Rol en la plataforma
                </label>
                <div className="flex gap-3">
                  {(["productor", "admin"] as const).map((r) => (
                    <button
                      key={r}
                      onClick={() => setForm((f) => ({ ...f, rol: r }))}
                      className="flex-1 py-3 rounded-xl border-2 text-sm font-semibold transition-all"
                      style={{
                        borderColor: form.rol === r ? "#4EBA2E" : "#E6F1E6",
                        background: form.rol === r ? "#E6F1E6" : "white",
                        color: form.rol === r ? "#1E3D2B" : "#868C5A",
                      }}
                    >
                      {r === "productor" ? "🐄 Productor" : "⚙️ Admin"}
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="step2"
              className="flex flex-col gap-4"
              initial={{ opacity: 0, x: 40 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -40 }}
              transition={{ duration: 0.3 }}
            >
              <h3 className="font-bold mb-1" style={{ color: "#0A1E16", fontFamily: "'Poppins', sans-serif", fontSize: "18px" }}>
                Creá tu contraseña
              </h3>
              <InputField
                label="Contraseña"
                icon={<Lock size={18} />}
                type={showPass ? "text" : "password"}
                placeholder="Mínimo 8 caracteres"
                value={form.password}
                onChange={set("password")}
                right={
                  <button type="button" onClick={() => setShowPass(!showPass)}>
                    {showPass ? <EyeOff size={16} style={{ color: "#868C5A" }} /> : <Eye size={16} style={{ color: "#868C5A" }} />}
                  </button>
                }
              />
              <InputField
                label="Confirmar contraseña"
                icon={<Lock size={18} />}
                type={showConfirm ? "text" : "password"}
                placeholder="Repetí tu contraseña"
                value={form.confirm}
                onChange={set("confirm")}
                right={
                  <button type="button" onClick={() => setShowConfirm(!showConfirm)}>
                    {showConfirm ? <EyeOff size={16} style={{ color: "#868C5A" }} /> : <Eye size={16} style={{ color: "#868C5A" }} />}
                  </button>
                }
              />
              {/* Password strength */}
              {form.password && (
                <div>
                  <div className="flex gap-1 mb-1">
                    {[0, 1, 2, 3].map((i) => (
                      <div
                        key={i}
                        className="flex-1 h-1 rounded-full"
                        style={{
                          background:
                            form.password.length > i * 3
                              ? i < 2 ? "#f59e0b" : "#4EBA2E"
                              : "#E6F1E6",
                        }}
                      />
                    ))}
                  </div>
                  <p className="text-xs" style={{ color: "#868C5A" }}>
                    {form.password.length < 6 ? "Contraseña débil" : form.password.length < 10 ? "Contraseña regular" : "Contraseña fuerte ✓"}
                  </p>
                </div>
              )}
              {/* T&C */}
              <p className="text-xs text-center mt-2" style={{ color: "#868C5A" }}>
                Al registrarte aceptás los{" "}
                <span style={{ color: "#4EBA2E" }}>Términos y Condiciones</span> y la{" "}
                <span style={{ color: "#4EBA2E" }}>Política de Privacidad</span> de VacApp.
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* CTA */}
        <button
          onClick={next}
          disabled={loading}
          className="w-full h-14 rounded-2xl flex items-center justify-center gap-2 mt-7 shadow-md active:scale-95 transition-transform disabled:opacity-70"
          style={{ background: "linear-gradient(135deg, #4EBA2E, #1E3D2B)" }}
        >
          {loading ? (
            <div className="w-5 h-5 border-2 border-white/40 border-t-white rounded-full animate-spin" />
          ) : (
            <span className="text-white font-semibold">
              {step < 2 ? "Continuar" : "Crear cuenta"}
            </span>
          )}
        </button>

        <div className="flex items-center justify-center gap-1 mt-5">
          <span className="text-sm" style={{ color: "#868C5A" }}>¿Ya tenés cuenta?</span>
          <button onClick={() => navigate("/login")} className="text-sm font-semibold" style={{ color: "#4EBA2E" }}>
            Iniciá sesión
          </button>
        </div>
      </div>
    </div>
  );
}
