import { useState } from "react";
import { useNavigate } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { ChevronRight, Dna, ShieldCheck, QrCode } from "lucide-react";

const SLIDES = [
  {
    id: 0,
    icon: <Dna size={56} strokeWidth={1.5} />,
    bg: "linear-gradient(160deg, #0A1E16 0%, #1E3D2B 100%)",
    accent: "#4EBA2E",
    title: "Genética que Cruza",
    subtitle: "Mejora que se ve",
    body: "Accedé a los mejores reproductores del país con datos genéticos verificados. DEP, EBV y proyección de cría al alcance de tu mano.",
    emoji: "🧬",
  },
  {
    id: 1,
    icon: <ShieldCheck size={56} strokeWidth={1.5} />,
    bg: "linear-gradient(160deg, #1E3D2B 0%, #2d5c3a 100%)",
    accent: "#4EBA2E",
    title: "KYC & Trazabilidad",
    subtitle: "Confianza garantizada",
    body: "Cada vendedor es verificado con DNI, CUIT y documentación. Comprá con total seguridad sabiendo quién está del otro lado.",
    emoji: "✅",
  },
  {
    id: 2,
    icon: <QrCode size={56} strokeWidth={1.5} />,
    bg: "linear-gradient(160deg, #0A1E16 0%, #1E3D2B 100%)",
    accent: "#4EBA2E",
    title: "Cierre In Situ",
    subtitle: "QR único en el campo",
    body: "Generamos un código QR único para confirmar la transacción en el momento exacto de la entrega. Evidencia legal, sin papeleos.",
    emoji: "📱",
  },
];

export function OnboardingScreen() {
  const [current, setCurrent] = useState(0);
  const navigate = useNavigate();

  const slide = SLIDES[current];
  const isLast = current === SLIDES.length - 1;

  const next = () => {
    if (isLast) {
      navigate("/login");
    } else {
      setCurrent((c) => c + 1);
    }
  };

  const skip = () => navigate("/login");

  return (
    <div
      className="relative flex flex-col items-center justify-between w-full h-full overflow-hidden"
      style={{ background: slide.bg, transition: "background 0.6s ease" }}
    >
      {/* Skip button */}
      {!isLast && (
        <div className="w-full flex justify-end px-6 pt-14 z-10">
          <button onClick={skip} className="text-white/50 text-sm">
            Saltar
          </button>
        </div>
      )}

      {/* Main content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={current}
          className="flex-1 flex flex-col items-center justify-center px-8 z-10 pb-4"
          initial={{ opacity: 0, x: 60 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -60 }}
          transition={{ duration: 0.4, ease: "easeOut" }}
        >
          {/* Icon circle */}
          <div
            className="w-32 h-32 rounded-full flex items-center justify-center mb-8 shadow-xl"
            style={{ background: "rgba(78,186,46,0.15)", border: "2px solid rgba(78,186,46,0.3)" }}
          >
            <div style={{ color: "#4EBA2E" }}>
              {slide.icon}
            </div>
          </div>

          {/* Emoji badge */}
          <div
            className="w-14 h-14 rounded-full flex items-center justify-center text-2xl mb-6 -mt-16 ml-20 shadow-lg"
            style={{ background: "#4EBA2E" }}
          >
            {slide.emoji}
          </div>

          <h1
            className="text-white text-center mb-1"
            style={{ fontFamily: "'Poppins', sans-serif", fontSize: "28px", fontWeight: 700 }}
          >
            {slide.title}
          </h1>
          <p className="text-sm mb-6" style={{ color: "#4EBA2E", letterSpacing: "1.5px", textTransform: "uppercase" }}>
            {slide.subtitle}
          </p>
          <p className="text-center leading-relaxed" style={{ color: "rgba(255,255,255,0.7)", fontSize: "15px" }}>
            {slide.body}
          </p>
        </motion.div>
      </AnimatePresence>

      {/* Bottom section */}
      <div className="w-full px-6 pb-12 z-10 flex flex-col items-center gap-6">
        {/* Dots */}
        <div className="flex gap-2">
          {SLIDES.map((_, i) => (
            <button key={i} onClick={() => setCurrent(i)}>
              <motion.div
                animate={{ width: i === current ? 24 : 8 }}
                transition={{ duration: 0.3 }}
                className="h-2 rounded-full"
                style={{ background: i === current ? "#4EBA2E" : "rgba(255,255,255,0.25)" }}
              />
            </button>
          ))}
        </div>

        {/* CTA Button */}
        <button
          onClick={next}
          className="w-full h-14 rounded-2xl flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-transform"
          style={{ background: "#4EBA2E" }}
        >
          <span className="text-white font-semibold text-base">
            {isLast ? "Empezar ahora" : "Continuar"}
          </span>
          <ChevronRight size={20} className="text-white" />
        </button>

        {isLast && (
          <button onClick={skip} className="text-sm" style={{ color: "rgba(255,255,255,0.5)" }}>
            Ya tengo una cuenta → Iniciar sesión
          </button>
        )}
      </div>

      {/* Wave bottom decoration */}
      <svg
        viewBox="0 0 390 60"
        className="absolute bottom-0 left-0 w-full opacity-10"
        preserveAspectRatio="none"
        style={{ pointerEvents: "none" }}
      >
        <path d="M0 30 Q97 0 195 30 Q293 60 390 20 L390 60 L0 60 Z" fill="#4EBA2E" />
      </svg>
    </div>
  );
}
