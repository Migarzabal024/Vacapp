import { useState } from "react";
import { useNavigate } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { Search, Bell, MapPin, Star, Shield, ChevronRight, Plus, Home, Grid3x3, Receipt, User, TrendingUp, Dna } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export type Animal = {
  id: string;
  name: string;
  breed: string;
  category: string;
  age: number;
  weight: number;
  price: number;
  location: string;
  province: string;
  geneticRank: string;
  seller: string;
  sellerRating: number;
  sellerVerified: boolean;
  reproductiveHistory: string;
  geneticProjection: string;
  image: string;
  tags: string[];
};

export const ANIMALS: Animal[] = [
  {
    id: "1",
    name: "Torito Génesis",
    breed: "Aberdeen Angus",
    category: "toros",
    age: 18,
    weight: 480,
    price: 850000,
    location: "Córdoba",
    province: "Córdoba, AR",
    geneticRank: "Elite",
    seller: "Juan M. Berazategui",
    sellerRating: 4.8,
    sellerVerified: true,
    reproductiveHistory: "Sin servicio previo",
    geneticProjection: "DEP Peso destete: +28 | DEP Terneza: +0.8",
    image: "https://images.unsplash.com/photo-1654120006672-efbfc299938e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
    tags: ["KYC", "Premium"],
  },
  {
    id: "2",
    name: "Vaca Estrella VII",
    breed: "Hereford",
    category: "vacas",
    age: 36,
    weight: 520,
    price: 620000,
    location: "General Pico",
    province: "La Pampa, AR",
    geneticRank: "Superior",
    seller: "Estancia La Esperanza",
    sellerRating: 4.6,
    sellerVerified: true,
    reproductiveHistory: "2 partos normales",
    geneticProjection: "DEP Leche: +180 | DEP Fertilidad: +12",
    image: "https://images.unsplash.com/photo-1613443600547-37f29323fe7c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
    tags: ["Trazabilidad", "Preñez"],
  },
  {
    id: "3",
    name: "Novillo Zeus III",
    breed: "Braford",
    category: "novillos",
    age: 24,
    weight: 550,
    price: 720000,
    location: "Resistencia",
    province: "Chaco, AR",
    geneticRank: "Premium",
    seller: "El Fortín Ganadero",
    sellerRating: 4.9,
    sellerVerified: true,
    reproductiveHistory: "No aplica",
    geneticProjection: "DEP Ganancia: +0.45 | DEP Área bife: +1.2",
    image: "https://images.unsplash.com/photo-1635456268737-8610b8673b0d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
    tags: ["Engorde", "Premium"],
  },
  {
    id: "4",
    name: "Vaquillona Luna",
    breed: "Brangus",
    category: "vaquillonas",
    age: 20,
    weight: 380,
    price: 480000,
    location: "Corrientes",
    province: "Corrientes, AR",
    geneticRank: "Elite",
    seller: "Hacienda Don Rubén",
    sellerRating: 4.5,
    sellerVerified: false,
    reproductiveHistory: "Sin servicio previo",
    geneticProjection: "DEP Adaptación calor: Alta | DEP Preñez: +15",
    image: "https://images.unsplash.com/photo-1558152761-aee570eb5cb0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
    tags: ["Tropical"],
  },
  {
    id: "5",
    name: "Toro Prometeo",
    breed: "Limousin",
    category: "toros",
    age: 30,
    weight: 820,
    price: 1850000,
    location: "Pergamino",
    province: "Buenos Aires, AR",
    geneticRank: "Élite Internacional",
    seller: "Genética Pampeana S.A.",
    sellerRating: 5.0,
    sellerVerified: true,
    reproductiveHistory: "420 servicios registrados",
    geneticProjection: "EBV Terneza: +9.8 | EBV Ganancia: +58",
    image: "https://images.unsplash.com/photo-1667912300809-65cb6e28c135?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
    tags: ["KYC", "Elite Internacional"],
  },
  {
    id: "6",
    name: "Vaca Pampa I",
    breed: "Angus Colorado",
    category: "vacas",
    age: 42,
    weight: 490,
    price: 540000,
    location: "Bahía Blanca",
    province: "Buenos Aires, AR",
    geneticRank: "Superior",
    seller: "Rodeo Las Pampas",
    sellerRating: 4.3,
    sellerVerified: true,
    reproductiveHistory: "3 partos, preñez actual",
    geneticProjection: "DEP Peso nacer: -1.2 | DEP Destete: +22",
    image: "https://images.unsplash.com/photo-1617020602682-1dbc00fa660e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
    tags: ["Preñez", "Verificado"],
  },
  {
    id: "7",
    name: "Herd Reserve 12",
    breed: "Shorthorn",
    category: "novillos",
    age: 28,
    weight: 590,
    price: 660000,
    location: "Santa Rosa",
    province: "La Pampa, AR",
    geneticRank: "Superior",
    seller: "Campos del Sur",
    sellerRating: 4.7,
    sellerVerified: true,
    reproductiveHistory: "No aplica",
    geneticProjection: "DEP Conformación: +8 | DEP Terneza: +1.1",
    image: "https://images.unsplash.com/photo-1709483076536-caf837728ced?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
    tags: ["Engorde"],
  },
  {
    id: "8",
    name: "Vaquillona Esperanza",
    breed: "Angus Negro",
    category: "vaquillonas",
    age: 16,
    weight: 310,
    price: 395000,
    location: "Azul",
    province: "Buenos Aires, AR",
    geneticRank: "Premium",
    seller: "El Ombu SA",
    sellerRating: 4.4,
    sellerVerified: false,
    reproductiveHistory: "Sin servicio previo",
    geneticProjection: "DEP Peso adulto: +32 | DEP Condición: +2.1",
    image: "https://images.unsplash.com/reserve/tv3te4tNQsugPmYU4Aj7_KS_CattleFence.jpg?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
    tags: ["Joven"],
  },
];

const CATEGORIES = [
  { key: "todos", label: "Todos", emoji: "🐄" },
  { key: "toros", label: "Toros", emoji: "🐂" },
  { key: "vacas", label: "Vacas", emoji: "🐮" },
  { key: "novillos", label: "Novillos", emoji: "🥩" },
  { key: "vaquillonas", label: "Vaquillonas", emoji: "🌿" },
];

const RANK_COLORS: Record<string, string> = {
  "Elite": "#4EBA2E",
  "Élite Internacional": "#4EBA2E",
  "Superior": "#1E3D2B",
  "Premium": "#868C5A",
};

function formatPrice(n: number) {
  return new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS", maximumFractionDigits: 0 }).format(n);
}

function AnimalCard({ animal, onPress }: { animal: Animal; onPress: () => void }) {
  return (
    <motion.div
      whileTap={{ scale: 0.97 }}
      onClick={onPress}
      className="rounded-2xl overflow-hidden shadow-sm border cursor-pointer"
      style={{ borderColor: "#E6F1E6", background: "white" }}
    >
      {/* Image */}
      <div className="relative h-44 overflow-hidden">
        <ImageWithFallback
          src={animal.image}
          alt={animal.name}
          className="w-full h-full object-cover"
        />
        {/* Gradient overlay */}
        <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(10,30,22,0.7) 0%, transparent 50%)" }} />
        {/* Rank badge */}
        <div
          className="absolute top-2 left-2 px-2 py-0.5 rounded-full flex items-center gap-1"
          style={{ background: RANK_COLORS[animal.geneticRank] || "#1E3D2B" }}
        >
          <Dna size={10} className="text-white" />
          <span className="text-white text-xs font-semibold">{animal.geneticRank}</span>
        </div>
        {/* Verified */}
        {animal.sellerVerified && (
          <div className="absolute top-2 right-2 w-7 h-7 rounded-full bg-[#4EBA2E] flex items-center justify-center">
            <Shield size={14} className="text-white" />
          </div>
        )}
        {/* Name over image */}
        <div className="absolute bottom-2 left-3 right-3">
          <p className="text-white font-bold text-sm leading-tight" style={{ fontFamily: "'Poppins', sans-serif" }}>
            {animal.name}
          </p>
          <p className="text-white/70 text-xs">{animal.breed}</p>
        </div>
      </div>

      {/* Card body */}
      <div className="p-3">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1">
            <MapPin size={11} style={{ color: "#868C5A" }} />
            <span className="text-xs" style={{ color: "#868C5A" }}>{animal.location}</span>
          </div>
          <div className="flex items-center gap-1">
            <Star size={11} fill="#f59e0b" stroke="none" />
            <span className="text-xs font-semibold" style={{ color: "#1A1A1A" }}>{animal.sellerRating}</span>
          </div>
        </div>

        <div className="flex items-center gap-3 mb-2 text-xs" style={{ color: "#868C5A" }}>
          <span>{animal.age} meses</span>
          <span>•</span>
          <span>{animal.weight} kg</span>
        </div>

        <div className="flex items-center justify-between">
          <p className="font-bold" style={{ color: "#0A1E16", fontSize: "15px", fontFamily: "'Poppins', sans-serif" }}>
            {formatPrice(animal.price)}
          </p>
          <div
            className="w-8 h-8 rounded-xl flex items-center justify-center"
            style={{ background: "#E6F1E6" }}
          >
            <ChevronRight size={16} style={{ color: "#1E3D2B" }} />
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function FeaturedCard({ animal, onPress }: { animal: Animal; onPress: () => void }) {
  return (
    <motion.div
      whileTap={{ scale: 0.97 }}
      onClick={onPress}
      className="relative rounded-3xl overflow-hidden cursor-pointer flex-shrink-0"
      style={{ width: "280px", height: "180px" }}
    >
      <ImageWithFallback
        src={animal.image}
        alt={animal.name}
        className="w-full h-full object-cover"
      />
      <div className="absolute inset-0" style={{ background: "linear-gradient(135deg, rgba(10,30,22,0.85) 0%, rgba(10,30,22,0.2) 100%)" }} />
      <div className="absolute inset-0 p-4 flex flex-col justify-between">
        <div className="flex items-center gap-1.5">
          <div className="px-2 py-0.5 rounded-full" style={{ background: "#4EBA2E" }}>
            <span className="text-white text-xs font-bold">⭐ Destacado</span>
          </div>
        </div>
        <div>
          <p className="text-white font-bold" style={{ fontFamily: "'Poppins', sans-serif", fontSize: "16px" }}>{animal.name}</p>
          <p className="text-white/70 text-xs mb-2">{animal.breed} · {animal.province}</p>
          <p className="font-bold" style={{ color: "#4EBA2E", fontSize: "17px", fontFamily: "'Poppins', sans-serif" }}>
            {formatPrice(animal.price)}
          </p>
        </div>
      </div>
    </motion.div>
  );
}

const BOTTOM_NAV = [
  { icon: Home, label: "Inicio", tab: "home" },
  { icon: Grid3x3, label: "Explorar", tab: "explore" },
  { icon: TrendingUp, label: "Mercado", tab: "market" },
  { icon: Receipt, label: "Transacc.", tab: "transactions" },
  { icon: User, label: "Perfil", tab: "profile" },
];

export function HomeScreen() {
  const navigate = useNavigate();
  const [activeCategory, setActiveCategory] = useState("todos");
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("home");

  const filtered = ANIMALS.filter((a) => {
    const matchCat = activeCategory === "todos" || a.category === activeCategory;
    const matchSearch = !searchQuery || a.name.toLowerCase().includes(searchQuery.toLowerCase()) || a.breed.toLowerCase().includes(searchQuery.toLowerCase());
    return matchCat && matchSearch;
  });

  const featured = ANIMALS.filter((a) => a.sellerVerified && a.sellerRating >= 4.8);

  return (
    <div className="flex flex-col w-full h-full bg-[#F2F2F2] overflow-hidden">
      {/* Header */}
      <div
        className="px-5 pt-12 pb-5"
        style={{ background: "linear-gradient(160deg, #0A1E16 0%, #1E3D2B 100%)" }}
      >
        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="text-xs" style={{ color: "#868C5A", letterSpacing: "0.5px" }}>Bienvenido,</p>
            <h1 className="text-white font-bold" style={{ fontFamily: "'Poppins', sans-serif", fontSize: "20px" }}>
              Juan González 👋
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <button className="relative w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: "rgba(255,255,255,0.1)" }}>
              <Bell size={20} className="text-white" />
              <div className="absolute top-2 right-2 w-2 h-2 rounded-full bg-[#4EBA2E]" />
            </button>
            <div className="w-10 h-10 rounded-xl overflow-hidden border-2 border-[#4EBA2E]">
              <div className="w-full h-full flex items-center justify-center text-lg" style={{ background: "#4EBA2E" }}>
                🐄
              </div>
            </div>
          </div>
        </div>

        {/* Search */}
        <div className="flex items-center gap-3 rounded-xl px-4 py-3" style={{ background: "rgba(255,255,255,0.1)" }}>
          <Search size={18} style={{ color: "rgba(255,255,255,0.5)" }} />
          <input
            placeholder="Buscar raza, animal..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-1 bg-transparent outline-none text-sm placeholder:text-white/40 text-white"
          />
        </div>
      </div>

      {/* Scrollable content */}
      <div className="flex-1 overflow-y-auto pb-20">
        {/* Stats row */}
        <div className="flex gap-3 px-4 pt-4 pb-2">
          {[
            { label: "Publicaciones", value: "1.240", color: "#1E3D2B", emoji: "📋" },
            { label: "Provincias", value: "23", color: "#4EBA2E", emoji: "🗺" },
            { label: "Vendedores", value: "340+", color: "#868C5A", emoji: "🤝" },
          ].map((s) => (
            <div key={s.label} className="flex-1 rounded-2xl p-3 flex flex-col gap-1" style={{ background: "white" }}>
              <span className="text-base">{s.emoji}</span>
              <p className="font-bold" style={{ color: s.color, fontFamily: "'Poppins', sans-serif", fontSize: "16px" }}>{s.value}</p>
              <p className="text-xs" style={{ color: "#868C5A" }}>{s.label}</p>
            </div>
          ))}
        </div>

        {/* Featured horizontal scroll */}
        {!searchQuery && (
          <div className="mt-2">
            <div className="flex items-center justify-between px-4 mb-3">
              <h2 className="font-bold" style={{ color: "#0A1E16", fontFamily: "'Poppins', sans-serif", fontSize: "15px" }}>
                Destacados
              </h2>
              <button className="text-xs font-semibold" style={{ color: "#4EBA2E" }}>Ver todos</button>
            </div>
            <div className="flex gap-3 px-4 overflow-x-auto pb-1" style={{ scrollbarWidth: "none" }}>
              {featured.map((a) => (
                <FeaturedCard key={a.id} animal={a} onPress={() => navigate(`/animal/${a.id}`)} />
              ))}
            </div>
          </div>
        )}

        {/* Category filter */}
        <div className="mt-4">
          <div className="flex gap-2 px-4 overflow-x-auto pb-1" style={{ scrollbarWidth: "none" }}>
            {CATEGORIES.map((cat) => (
              <button
                key={cat.key}
                onClick={() => setActiveCategory(cat.key)}
                className="flex-shrink-0 flex items-center gap-1.5 px-4 py-2 rounded-full text-sm transition-all"
                style={{
                  background: activeCategory === cat.key ? "#1E3D2B" : "white",
                  color: activeCategory === cat.key ? "white" : "#868C5A",
                  fontWeight: activeCategory === cat.key ? 600 : 400,
                  boxShadow: activeCategory === cat.key ? "0 2px 8px rgba(30,61,43,0.4)" : "none",
                }}
              >
                <span>{cat.emoji}</span>
                <span>{cat.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Grid */}
        <div className="px-4 mt-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-bold" style={{ color: "#0A1E16", fontFamily: "'Poppins', sans-serif", fontSize: "15px" }}>
              {filtered.length} publicaciones
            </h2>
          </div>
          <AnimatePresence>
            <div className="grid grid-cols-2 gap-3">
              {filtered.map((animal, i) => (
                <motion.div
                  key={animal.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                >
                  <AnimalCard animal={animal} onPress={() => navigate(`/animal/${animal.id}`)} />
                </motion.div>
              ))}
            </div>
          </AnimatePresence>

          {filtered.length === 0 && (
            <div className="flex flex-col items-center justify-center py-16 gap-3">
              <span className="text-5xl">🔍</span>
              <p className="font-semibold" style={{ color: "#1E3D2B" }}>Sin resultados</p>
              <p className="text-sm text-center" style={{ color: "#868C5A" }}>
                Intentá con otro término o categoría.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Bottom navigation */}
      <div
        className="absolute bottom-0 left-0 right-0 flex items-center justify-around px-2 py-3 border-t"
        style={{ background: "white", borderColor: "#E6F1E6" }}
      >
        {BOTTOM_NAV.map((item) => {
          const Icon = item.icon;
          const active = activeTab === item.tab;
          if (item.tab === "explore") {
            return (
              <button
                key={item.tab}
                onClick={() => setActiveTab(item.tab)}
                className="w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg -mt-4"
                style={{ background: "linear-gradient(135deg, #4EBA2E, #1E3D2B)" }}
              >
                <Plus size={22} className="text-white" />
              </button>
            );
          }
          return (
            <button
              key={item.tab}
              onClick={() => setActiveTab(item.tab)}
              className="flex flex-col items-center gap-1 px-2 py-1"
            >
              <Icon size={22} style={{ color: active ? "#4EBA2E" : "#868C5A" }} strokeWidth={active ? 2.5 : 1.5} />
              <span
                className="text-xs"
                style={{ color: active ? "#4EBA2E" : "#868C5A", fontWeight: active ? 600 : 400 }}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
