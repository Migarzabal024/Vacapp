import { useEffect } from "react";
import { useNavigate } from "react-router";
import { motion } from "motion/react";

function DNAHelix() {
  const steps = 16;
  const helixPoints = Array.from({ length: steps }, (_, i) => {
    const t = i / (steps - 1);
    const y = 40 + t * 520;
    const x1 = 50 + 22 * Math.sin(t * Math.PI * 5);
    const x2 = 50 - 22 * Math.sin(t * Math.PI * 5);
    const inFront = Math.sin(t * Math.PI * 5) > 0;
    return { y, x1, x2, inFront, t };
  });

  return (
    <svg viewBox="0 0 100 600" className="absolute right-0 top-0 h-full w-16 opacity-30" preserveAspectRatio="xMidYMid meet">
      {helixPoints.map((p, i) => (
        <g key={i}>
          {i < steps - 1 && (
            <>
              <line
                x1={p.x1} y1={p.y}
                x2={helixPoints[i + 1].x1} y2={helixPoints[i + 1].y}
                stroke="#4EBA2E" strokeWidth="2.5" strokeLinecap="round"
              />
              <line
                x1={p.x2} y1={p.y}
                x2={helixPoints[i + 1].x2} y2={helixPoints[i + 1].y}
                stroke="#E6F1E6" strokeWidth="2.5" strokeLinecap="round"
              />
            </>
          )}
          {i % 2 === 0 && (
            <line
              x1={p.x1} y1={p.y}
              x2={p.x2} y2={p.y}
              stroke="#868C5A" strokeWidth="1.5" strokeLinecap="round" opacity="0.8"
            />
          )}
          <circle cx={p.x1} cy={p.y} r="3.5" fill={p.inFront ? "#4EBA2E" : "#1E3D2B"} />
          <circle cx={p.x2} cy={p.y} r="3.5" fill={p.inFront ? "#E6F1E6" : "#4EBA2E"} />
        </g>
      ))}
    </svg>
  );
}

function CowSvg() {
  return (
    <svg viewBox="0 0 200 160" fill="none" className="w-64 h-auto">
      {/* body */}
      <ellipse cx="95" cy="115" rx="70" ry="38" fill="#1A1A1A" />
      {/* neck */}
      <ellipse cx="140" cy="90" rx="22" ry="28" fill="#1A1A1A" />
      {/* head */}
      <ellipse cx="155" cy="62" rx="30" ry="24" fill="#1A1A1A" />
      {/* ear left */}
      <ellipse cx="133" cy="42" rx="9" ry="13" fill="#1A1A1A" transform="rotate(-25 133 42)" />
      <ellipse cx="133" cy="43" rx="5" ry="9" fill="#4EBA2E" transform="rotate(-25 133 43)" />
      {/* ear right */}
      <ellipse cx="176" cy="44" rx="9" ry="13" fill="#1A1A1A" transform="rotate(25 176 44)" />
      <ellipse cx="176" cy="45" rx="5" ry="9" fill="#4EBA2E" transform="rotate(25 176 45)" />
      {/* white patch */}
      <ellipse cx="158" cy="58" rx="14" ry="12" fill="white" opacity="0.15" />
      {/* eye */}
      <circle cx="163" cy="58" r="6" fill="white" />
      <circle cx="163" cy="58" r="3.5" fill="#1A1A1A" />
      <circle cx="164.5" cy="56.5" r="1.2" fill="white" />
      {/* nose/muzzle */}
      <ellipse cx="170" cy="74" rx="14" ry="10" fill="#2d1a0e" />
      <circle cx="165" cy="74" r="3" fill="#1A1A1A" />
      <circle cx="175" cy="74" r="3" fill="#1A1A1A" />
      {/* legs */}
      <rect x="40" y="148" width="14" height="28" rx="5" fill="#1A1A1A" />
      <rect x="63" y="148" width="14" height="28" rx="5" fill="#1A1A1A" />
      <rect x="105" y="148" width="14" height="28" rx="5" fill="#1A1A1A" />
      <rect x="128" y="148" width="14" height="28" rx="5" fill="#1A1A1A" />
      {/* tail */}
      <path d="M 25 105 Q 10 85 18 65 Q 22 58 26 62" stroke="#1A1A1A" strokeWidth="5" fill="none" strokeLinecap="round" />
      <ellipse cx="22" cy="62" rx="8" ry="5" fill="#1A1A1A" transform="rotate(-20 22 62)" />
      {/* spots */}
      <ellipse cx="80" cy="100" rx="18" ry="12" fill="white" opacity="0.12" transform="rotate(-15 80 100)" />
      <ellipse cx="110" cy="120" rx="12" ry="8" fill="white" opacity="0.1" />
    </svg>
  );
}

export function SplashScreen() {
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setTimeout(() => navigate("/onboarding"), 3000);
    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div
      className="relative flex flex-col items-center justify-between w-full h-full overflow-hidden"
      style={{ background: "linear-gradient(170deg, #0A1E16 0%, #1E3D2B 55%, #0A1E16 100%)" }}
    >
      {/* Background hexagon pattern */}
      <div className="absolute inset-0 overflow-hidden opacity-10">
        {[...Array(8)].map((_, i) => (
          <div
            key={i}
            className="absolute border border-[#4EBA2E] rounded-lg"
            style={{
              width: `${40 + i * 18}px`,
              height: `${40 + i * 18}px`,
              top: `${Math.random() * 80}%`,
              left: `${Math.random() * 80}%`,
              transform: "rotate(45deg)",
              opacity: 0.4 + Math.random() * 0.4,
            }}
          />
        ))}
      </div>

      {/* DNA Helix */}
      <DNAHelix />

      {/* Left DNA strip */}
      <svg viewBox="0 0 100 600" className="absolute left-0 top-0 h-full w-10 opacity-15">
        {Array.from({ length: 10 }, (_, i) => {
          const y = 60 + i * 55;
          return (
            <g key={i}>
              <circle cx="50" cy={y} r="5" fill="#4EBA2E" />
              {i < 9 && <line x1="50" y1={y} x2="50" y2={y + 55} stroke="#4EBA2E" strokeWidth="1.5" />}
            </g>
          );
        })}
      </svg>

      {/* Top: Time + status bar placeholder */}
      <div className="w-full flex justify-between items-center px-6 pt-12 z-10">
        <span className="text-white/40 text-xs">9:41</span>
        <div className="flex gap-1">
          <div className="w-4 h-2 bg-white/40 rounded-sm" />
          <div className="w-1 h-2 bg-white/40 rounded-sm" />
        </div>
      </div>

      {/* Center: Logo */}
      <motion.div
        className="flex flex-col items-center z-10 -mt-8"
        initial={{ opacity: 0, scale: 0.85, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      >
        {/* Logo mark */}
        <motion.div
          className="w-24 h-24 rounded-full flex items-center justify-center mb-5 shadow-2xl"
          style={{ background: "linear-gradient(135deg, #4EBA2E, #1E3D2B)" }}
          animate={{ scale: [1, 1.04, 1] }}
          transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
        >
          <span className="text-5xl">🐄</span>
        </motion.div>

        {/* App Name */}
        <div className="flex items-baseline gap-0.5">
          <span
            className="text-white tracking-tight"
            style={{ fontFamily: "'Poppins', sans-serif", fontSize: "42px", fontWeight: 800, letterSpacing: "-1px" }}
          >
            Vac
          </span>
          <span
            style={{ fontFamily: "'Poppins', sans-serif", fontSize: "42px", fontWeight: 800, color: "#4EBA2E", letterSpacing: "-1px" }}
          >
            App
          </span>
        </div>

        <div className="flex items-center gap-2 mt-1">
          <div className="h-px w-8" style={{ background: "#4EBA2E" }} />
          <p className="text-xs tracking-widest uppercase" style={{ color: "#868C5A", letterSpacing: "3px" }}>
            Genética que cruza
          </p>
          <div className="h-px w-8" style={{ background: "#4EBA2E" }} />
        </div>

        <p className="text-xs mt-1 tracking-wider" style={{ color: "#4EBA2E", letterSpacing: "2px" }}>
          MEJORA QUE SE VE.
        </p>
      </motion.div>

      {/* Cow illustration */}
      <motion.div
        className="z-10 mb-4"
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.9, delay: 0.4, ease: "easeOut" }}
      >
        <CowSvg />
      </motion.div>

      {/* Bottom wave + loader */}
      <div className="w-full z-10">
        <svg viewBox="0 0 390 80" className="w-full" preserveAspectRatio="none">
          <path
            d="M0 40 Q48 10 97 30 Q146 50 195 25 Q244 0 293 25 Q342 50 390 20 L390 80 L0 80 Z"
            fill="#4EBA2E"
            opacity="0.25"
          />
          <path
            d="M0 55 Q65 25 130 50 Q195 75 260 45 Q325 15 390 50 L390 80 L0 80 Z"
            fill="#4EBA2E"
            opacity="0.4"
          />
          <path
            d="M0 65 Q97 45 195 65 Q293 85 390 60 L390 80 L0 80 Z"
            fill="#4EBA2E"
            opacity="0.7"
          />
        </svg>

        <div className="bg-[#4EBA2E]/70 w-full pb-8 flex flex-col items-center gap-3 -mt-1">
          {/* Loading dots */}
          <div className="flex gap-2">
            {[0, 1, 2].map((i) => (
              <motion.div
                key={i}
                className="w-2 h-2 rounded-full bg-white"
                animate={{ opacity: [0.3, 1, 0.3] }}
                transition={{ duration: 1.2, repeat: Infinity, delay: i * 0.25, ease: "easeInOut" }}
              />
            ))}
          </div>
          <p className="text-white/70 text-xs">Cargando...</p>
        </div>
      </div>
    </div>
  );
}
