import { useState } from "react";
import { useNavigate } from "react-router";
import { motion } from "motion/react";
import { Eye, EyeOff, Mail, Lock, ArrowRight } from "lucide-react";

export function LoginScreen() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError("Completá todos los campos.");
      return;
    }
    setError("");
    setLoading(true);
    await new Promise((r) => setTimeout(r, 1200));
    setLoading(false);
    navigate("/home");
  };

  return (
    <div className="flex flex-col w-full h-full bg-white overflow-y-auto">
      {/* Header green section */}
      <div
        className="relative flex flex-col items-center justify-end pb-10 pt-14 px-6"
        style={{ background: "linear-gradient(160deg, #0A1E16 0%, #1E3D2B 100%)", minHeight: "240px" }}
      >
        {/* DNA dots decoration */}
        <div className="absolute right-6 top-16 flex flex-col gap-3 opacity-20">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="flex gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-[#4EBA2E]" />
              <div className="w-1.5 h-1.5 rounded-full bg-white" />
            </div>
          ))}
        </div>

        <motion.div
          className="flex flex-col items-center"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div
            className="w-16 h-16 rounded-full flex items-center justify-center mb-3 shadow-lg"
            style={{ background: "linear-gradient(135deg, #4EBA2E, #1E3D2B)" }}
          >
            <span className="text-3xl">🐄</span>
          </div>
          <div className="flex items-baseline gap-0.5">
            <span className="text-white" style={{ fontFamily: "'Poppins', sans-serif", fontSize: "26px", fontWeight: 800 }}>
              Vac
            </span>
            <span style={{ fontFamily: "'Poppins', sans-serif", fontSize: "26px", fontWeight: 800, color: "#4EBA2E" }}>
              App
            </span>
          </div>
          <p className="text-xs mt-0.5" style={{ color: "#868C5A", letterSpacing: "2px" }}>
            GENÉTICA QUE CRUZA
          </p>
        </motion.div>
      </div>

      {/* Form card */}
      <motion.div
        className="flex-1 bg-white rounded-t-3xl -mt-6 px-6 pt-8 pb-6"
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.15 }}
      >
        <h2 className="mb-1" style={{ fontFamily: "'Poppins', sans-serif", fontSize: "22px", fontWeight: 700, color: "#0A1E16" }}>
          Bienvenido de nuevo
        </h2>
        <p className="text-sm mb-7" style={{ color: "#868C5A" }}>
          Iniciá sesión para continuar
        </p>

        <form onSubmit={handleLogin} className="flex flex-col gap-4">
          {/* Email */}
          <div>
            <label className="text-xs font-semibold mb-1.5 block" style={{ color: "#1E3D2B" }}>
              Correo electrónico
            </label>
            <div
              className="flex items-center gap-3 rounded-xl px-4 py-3.5 border"
              style={{ background: "#F2F2F2", borderColor: email ? "#4EBA2E" : "transparent" }}
            >
              <Mail size={18} style={{ color: "#868C5A" }} />
              <input
                type="email"
                placeholder="tu@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="flex-1 bg-transparent outline-none text-sm"
                style={{ color: "#1A1A1A" }}
              />
            </div>
          </div>

          {/* Password */}
          <div>
            <label className="text-xs font-semibold mb-1.5 block" style={{ color: "#1E3D2B" }}>
              Contraseña
            </label>
            <div
              className="flex items-center gap-3 rounded-xl px-4 py-3.5 border"
              style={{ background: "#F2F2F2", borderColor: password ? "#4EBA2E" : "transparent" }}
            >
              <Lock size={18} style={{ color: "#868C5A" }} />
              <input
                type={showPass ? "text" : "password"}
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="flex-1 bg-transparent outline-none text-sm"
                style={{ color: "#1A1A1A" }}
              />
              <button type="button" onClick={() => setShowPass(!showPass)}>
                {showPass ? <EyeOff size={18} style={{ color: "#868C5A" }} /> : <Eye size={18} style={{ color: "#868C5A" }} />}
              </button>
            </div>
          </div>

          {/* Forgot */}
          <div className="flex justify-end -mt-1">
            <button type="button" className="text-xs" style={{ color: "#4EBA2E" }}>
              ¿Olvidaste tu contraseña?
            </button>
          </div>

          {/* Error */}
          {error && (
            <p className="text-xs text-red-500 -mt-1">{error}</p>
          )}

          {/* Submit */}
          <button
            type="submit"
            disabled={loading}
            className="w-full h-14 rounded-2xl flex items-center justify-center gap-2 mt-2 shadow-md active:scale-95 transition-transform disabled:opacity-70"
            style={{ background: "linear-gradient(135deg, #4EBA2E, #1E3D2B)" }}
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white/40 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                <span className="text-white font-semibold">Iniciar sesión</span>
                <ArrowRight size={18} className="text-white" />
              </>
            )}
          </button>
        </form>

        {/* Divider */}
        <div className="flex items-center gap-3 my-5">
          <div className="flex-1 h-px bg-gray-200" />
          <span className="text-xs" style={{ color: "#868C5A" }}>o continuá con</span>
          <div className="flex-1 h-px bg-gray-200" />
        </div>

        {/* Social buttons */}
        <div className="flex gap-3">
          {["G", "f"].map((label, i) => (
            <button
              key={i}
              className="flex-1 h-12 rounded-xl border flex items-center justify-center gap-2 active:scale-95 transition-transform"
              style={{ borderColor: "#E6F1E6", background: "#F2F2F2" }}
              onClick={() => navigate("/home")}
            >
              <span className="font-bold text-sm" style={{ color: "#1E3D2B" }}>{label}</span>
              <span className="text-xs" style={{ color: "#868C5A" }}>{i === 0 ? "Google" : "Facebook"}</span>
            </button>
          ))}
        </div>

        {/* Register link */}
        <div className="flex items-center justify-center gap-1 mt-6">
          <span className="text-sm" style={{ color: "#868C5A" }}>¿No tenés cuenta?</span>
          <button
            onClick={() => navigate("/register")}
            className="text-sm font-semibold"
            style={{ color: "#4EBA2E" }}
          >
            Registrate gratis
          </button>
        </div>
      </motion.div>
    </div>
  );
}
