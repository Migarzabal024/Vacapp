import { useParams, useNavigate } from "react-router";
import { motion } from "motion/react";
import {
  ChevronLeft, Heart, Share2, MapPin, Star, Shield, Dna,
  Weight, Calendar, TrendingUp, User, MessageCircle, QrCode, Check
} from "lucide-react";
import { useState } from "react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { ANIMALS } from "./HomeScreen";

function formatPrice(n: number) {
  return new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS", maximumFractionDigits: 0 }).format(n);
}

const RANK_COLORS: Record<string, string> = {
  "Elite": "#4EBA2E",
  "Élite Internacional": "#4EBA2E",
  "Superior": "#1E3D2B",
  "Premium": "#868C5A",
};

export function AnimalDetailScreen() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [liked, setLiked] = useState(false);
  const [reserved, setReserved] = useState(false);
  const [reserving, setReserving] = useState(false);

  const animal = ANIMALS.find((a) => a.id === id);

  if (!animal) {
    return (
      <div className="flex flex-col items-center justify-center h-full gap-4">
        <span className="text-5xl">🐄</span>
        <p className="text-lg font-semibold" style={{ color: "#1E3D2B" }}>Animal no encontrado</p>
        <button onClick={() => navigate("/home")} className="text-sm" style={{ color: "#4EBA2E" }}>
          ← Volver al inicio
        </button>
      </div>
    );
  }

  const handleReserve = async () => {
    setReserving(true);
    await new Promise((r) => setTimeout(r, 1500));
    setReserving(false);
    setReserved(true);
  };

  return (
    <div className="flex flex-col w-full h-full bg-[#F2F2F2] overflow-hidden">
      {/* Hero image */}
      <div className="relative h-64 flex-shrink-0">
        <ImageWithFallback
          src={animal.image}
          alt={animal.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0" style={{ background: "linear-gradient(to bottom, rgba(0,0,0,0.25) 0%, transparent 40%, rgba(10,30,22,0.6) 100%)" }} />

        {/* Back + Actions */}
        <div className="absolute top-12 left-4 right-4 flex items-center justify-between">
          <button
            onClick={() => navigate("/home")}
            className="w-10 h-10 rounded-xl flex items-center justify-center backdrop-blur-sm"
            style={{ background: "rgba(255,255,255,0.2)" }}
          >
            <ChevronLeft size={22} className="text-white" />
          </button>
          <div className="flex gap-2">
            <button
              onClick={() => setLiked(!liked)}
              className="w-10 h-10 rounded-xl flex items-center justify-center backdrop-blur-sm"
              style={{ background: "rgba(255,255,255,0.2)" }}
            >
              <Heart
                size={18}
                className={liked ? "fill-red-400 stroke-red-400" : "text-white"}
              />
            </button>
            <button
              className="w-10 h-10 rounded-xl flex items-center justify-center backdrop-blur-sm"
              style={{ background: "rgba(255,255,255,0.2)" }}
            >
              <Share2 size={18} className="text-white" />
            </button>
          </div>
        </div>

        {/* Bottom of hero */}
        <div className="absolute bottom-4 left-4 right-4">
          <div className="flex items-center gap-2 mb-1">
            <div
              className="px-2 py-0.5 rounded-full flex items-center gap-1"
              style={{ background: RANK_COLORS[animal.geneticRank] || "#1E3D2B" }}
            >
              <Dna size={11} className="text-white" />
              <span className="text-white text-xs font-semibold">{animal.geneticRank}</span>
            </div>
            {animal.sellerVerified && (
              <div className="px-2 py-0.5 rounded-full flex items-center gap-1" style={{ background: "rgba(255,255,255,0.15)" }}>
                <Shield size={11} className="text-white" />
                <span className="text-white text-xs">KYC Verificado</span>
              </div>
            )}
          </div>
          <h1 className="text-white font-bold leading-tight" style={{ fontFamily: "'Poppins', sans-serif", fontSize: "22px" }}>
            {animal.name}
          </h1>
          <p className="text-white/80 text-sm">{animal.breed}</p>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto pb-28">
        {/* Price + location card */}
        <motion.div
          className="mx-4 -mt-4 rounded-2xl p-4 shadow-md"
          style={{ background: "white" }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs mb-0.5" style={{ color: "#868C5A" }}>Precio de venta</p>
              <p className="font-bold" style={{ color: "#0A1E16", fontFamily: "'Poppins', sans-serif", fontSize: "24px" }}>
                {formatPrice(animal.price)}
              </p>
            </div>
            <div className="flex items-center gap-1 px-3 py-1.5 rounded-xl" style={{ background: "#E6F1E6" }}>
              <MapPin size={14} style={{ color: "#1E3D2B" }} />
              <span className="text-sm font-semibold" style={{ color: "#1E3D2B" }}>{animal.province}</span>
            </div>
          </div>
        </motion.div>

        {/* Quick stats */}
        <motion.div
          className="flex gap-3 mx-4 mt-3"
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          {[
            { icon: <Calendar size={18} style={{ color: "#4EBA2E" }} />, label: "Edad", value: `${animal.age} meses` },
            { icon: <Weight size={18} style={{ color: "#4EBA2E" }} />, label: "Peso vivo", value: `${animal.weight} kg` },
            { icon: <TrendingUp size={18} style={{ color: "#4EBA2E" }} />, label: "Clasificación", value: animal.geneticRank },
          ].map((stat) => (
            <div key={stat.label} className="flex-1 rounded-2xl p-3 flex flex-col items-center gap-1" style={{ background: "white" }}>
              {stat.icon}
              <p className="font-bold text-sm text-center" style={{ color: "#0A1E16" }}>{stat.value}</p>
              <p className="text-xs text-center" style={{ color: "#868C5A" }}>{stat.label}</p>
            </div>
          ))}
        </motion.div>

        {/* Tags */}
        {animal.tags.length > 0 && (
          <div className="flex gap-2 mx-4 mt-3 flex-wrap">
            {animal.tags.map((tag) => (
              <span
                key={tag}
                className="px-3 py-1 rounded-full text-xs font-semibold"
                style={{ background: "#E6F1E6", color: "#1E3D2B" }}
              >
                {tag}
              </span>
            ))}
          </div>
        )}

        {/* Genetic projection */}
        <motion.div
          className="mx-4 mt-3 rounded-2xl p-4"
          style={{ background: "white" }}
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
        >
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: "#E6F1E6" }}>
              <Dna size={16} style={{ color: "#4EBA2E" }} />
            </div>
            <h3 className="font-bold" style={{ color: "#0A1E16", fontFamily: "'Poppins', sans-serif" }}>
              Proyección Genética
            </h3>
          </div>
          <p className="text-sm leading-relaxed" style={{ color: "#1E3D2B" }}>{animal.geneticProjection}</p>
        </motion.div>

        {/* Reproductive history */}
        <motion.div
          className="mx-4 mt-3 rounded-2xl p-4"
          style={{ background: "white" }}
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <h3 className="font-bold mb-2" style={{ color: "#0A1E16", fontFamily: "'Poppins', sans-serif" }}>
            Historial Reproductivo
          </h3>
          <p className="text-sm" style={{ color: "#868C5A" }}>{animal.reproductiveHistory}</p>
        </motion.div>

        {/* Seller info */}
        <motion.div
          className="mx-4 mt-3 rounded-2xl p-4"
          style={{ background: "white" }}
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
        >
          <h3 className="font-bold mb-3" style={{ color: "#0A1E16", fontFamily: "'Poppins', sans-serif" }}>
            Vendedor
          </h3>
          <div className="flex items-center gap-3">
            <div
              className="w-12 h-12 rounded-2xl flex items-center justify-center text-xl"
              style={{ background: "#E6F1E6" }}
            >
              {animal.sellerVerified ? "✅" : "👤"}
            </div>
            <div className="flex-1">
              <p className="font-semibold text-sm" style={{ color: "#0A1E16" }}>{animal.seller}</p>
              <div className="flex items-center gap-1 mt-0.5">
                <Star size={12} fill="#f59e0b" stroke="none" />
                <span className="text-xs font-semibold" style={{ color: "#1A1A1A" }}>{animal.sellerRating}</span>
                {animal.sellerVerified && (
                  <div className="flex items-center gap-1 ml-1 px-1.5 py-0.5 rounded-full" style={{ background: "#E6F1E6" }}>
                    <Shield size={10} style={{ color: "#4EBA2E" }} />
                    <span className="text-xs" style={{ color: "#4EBA2E" }}>KYC</span>
                  </div>
                )}
              </div>
            </div>
            <button
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ background: "#E6F1E6" }}
            >
              <MessageCircle size={18} style={{ color: "#1E3D2B" }} />
            </button>
          </div>
        </motion.div>

        {/* QR info */}
        <motion.div
          className="mx-4 mt-3 mb-4 rounded-2xl p-4 flex items-center gap-3"
          style={{ background: "linear-gradient(135deg, #0A1E16, #1E3D2B)" }}
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: "rgba(78,186,46,0.2)" }}>
            <QrCode size={24} style={{ color: "#4EBA2E" }} />
          </div>
          <div>
            <p className="font-semibold text-sm text-white">Cierre con QR in situ</p>
            <p className="text-xs mt-0.5" style={{ color: "rgba(255,255,255,0.6)" }}>
              Al reservar se genera un código QR único. La transacción se confirma en el campo.
            </p>
          </div>
        </motion.div>
      </div>

      {/* Bottom CTA */}
      <div
        className="absolute bottom-0 left-0 right-0 p-4 border-t"
        style={{ background: "white", borderColor: "#E6F1E6" }}
      >
        <div className="flex gap-3">
          <button
            className="w-14 h-14 rounded-2xl flex items-center justify-center border-2"
            style={{ borderColor: "#E6F1E6" }}
            onClick={() => setLiked(!liked)}
          >
            <Heart size={20} className={liked ? "fill-red-400 stroke-red-400" : ""} style={{ color: liked ? undefined : "#868C5A" }} />
          </button>
          <button
            onClick={handleReserve}
            disabled={reserving || reserved}
            className="flex-1 h-14 rounded-2xl flex items-center justify-center gap-2 shadow-md active:scale-95 transition-all disabled:opacity-80"
            style={{ background: reserved ? "#1E3D2B" : "linear-gradient(135deg, #4EBA2E, #1E3D2B)" }}
          >
            {reserving ? (
              <div className="w-5 h-5 border-2 border-white/40 border-t-white rounded-full animate-spin" />
            ) : reserved ? (
              <>
                <Check size={18} className="text-white" />
                <span className="text-white font-semibold">Reserva confirmada</span>
              </>
            ) : (
              <>
                <QrCode size={18} className="text-white" />
                <span className="text-white font-semibold">Reservar ahora</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
