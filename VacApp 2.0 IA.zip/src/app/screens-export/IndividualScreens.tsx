/**
 * Página para exportar pantallas individuales de VacaApp a Figma.
 * Cada pantalla tiene su propia ruta para facilitar la captura individual.
 */

import { useParams, useNavigate } from "react-router";
import { ExportFrame } from "./ExportFrame";
import { SplashScreen } from "../components/SplashScreen";
import { OnboardingScreen } from "../components/OnboardingScreen";
import { LoginScreen } from "../components/LoginScreen";
import { RegisterScreen } from "../components/RegisterScreen";
import { HomeScreen } from "../components/HomeScreen";
import { AnimalDetailScreen } from "../components/AnimalDetailScreen";

const SCREENS = [
  { id: "splash", name: "Splash Screen", Component: SplashScreen, description: "Pantalla de bienvenida con logo animado y DNA helix" },
  { id: "onboarding", name: "Onboarding", Component: OnboardingScreen, description: "3 slides: Genética, KYC, Cierre QR" },
  { id: "login", name: "Login", Component: LoginScreen, description: "Inicio de sesión con email/password y social login" },
  { id: "register", name: "Register", Component: RegisterScreen, description: "Registro en 3 pasos: datos personales, fiscales, seguridad" },
  { id: "home", name: "Home", Component: HomeScreen, description: "Pantalla principal con carrusel de destacados y grid de animales" },
  { id: "detail", name: "Animal Detail", Component: AnimalDetailScreen, description: "Detalle del animal con genética y botón de reserva QR" },
] as const;

export function IndividualScreens() {
  const { screenId } = useParams<{ screenId: string }>();
  const navigate = useNavigate();

  if (!screenId) {
    return (
      <div className="min-h-screen p-8" style={{ background: "#F0F0F0" }}>
        <div className="max-w-4xl mx-auto">
          <h1
            className="text-3xl font-bold mb-8"
            style={{ fontFamily: "'Poppins', sans-serif", color: "#0A1E16" }}
          >
            Exportar Pantalla Individual
          </h1>

          <div className="grid grid-cols-2 gap-4">
            {SCREENS.map((screen) => (
              <button
                key={screen.id}
                onClick={() => navigate(`/export/${screen.id}`)}
                className="p-6 rounded-2xl border-2 border-transparent hover:border-[#4EBA2E] transition-all text-left"
                style={{ background: "white" }}
              >
                <h2
                  className="text-xl font-bold mb-2"
                  style={{ fontFamily: "'Poppins', sans-serif", color: "#0A1E16" }}
                >
                  {screen.name}
                </h2>
                <p className="text-sm" style={{ color: "#868C5A" }}>
                  {screen.description}
                </p>
                <div className="mt-3 text-sm font-semibold" style={{ color: "#4EBA2E" }}>
                  Ver pantalla →
                </div>
              </button>
            ))}
          </div>

          <div className="mt-8 p-6 rounded-2xl" style={{ background: "white" }}>
            <h2
              className="text-xl font-bold mb-3"
              style={{ fontFamily: "'Poppins', sans-serif", color: "#0A1E16" }}
            >
              Rutas disponibles:
            </h2>
            <ul className="space-y-1 text-sm font-mono" style={{ color: "#1E3D2B" }}>
              {SCREENS.map((screen) => (
                <li key={screen.id}>
                  /export/{screen.id}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    );
  }

  const screen = SCREENS.find((s) => s.id === screenId);

  if (!screen) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#F0F0F0" }}>
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4" style={{ color: "#0A1E16" }}>
            Pantalla no encontrada
          </h1>
          <button
            onClick={() => navigate("/export")}
            className="text-sm font-semibold"
            style={{ color: "#4EBA2E" }}
          >
            ← Volver al índice
          </button>
        </div>
      </div>
    );
  }

  const ScreenComponent = screen.Component;

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-8" style={{ background: "#F0F0F0" }}>
      <div className="mb-6 flex items-center gap-4">
        <button
          onClick={() => navigate("/export")}
          className="text-sm font-semibold"
          style={{ color: "#4EBA2E" }}
        >
          ← Volver
        </button>
        <h1
          className="text-2xl font-bold"
          style={{ fontFamily: "'Poppins', sans-serif", color: "#0A1E16" }}
        >
          {screen.name}
        </h1>
      </div>

      <ExportFrame frameName={screen.id} description={screen.description}>
        <ScreenComponent />
      </ExportFrame>

      <div className="mt-6 p-4 rounded-xl max-w-md text-center" style={{ background: "white" }}>
        <p className="text-sm mb-2" style={{ color: "#868C5A" }}>
          {screen.description}
        </p>
        <p className="text-xs font-mono" style={{ color: "#1E3D2B" }}>
          Dimensiones: 390x844px
        </p>
      </div>

      <div className="mt-4 flex gap-3">
        {SCREENS.map((s, idx) => (
          <button
            key={s.id}
            onClick={() => navigate(`/export/${s.id}`)}
            className="w-10 h-10 rounded-xl flex items-center justify-center font-bold transition-all"
            style={{
              background: s.id === screenId ? "#4EBA2E" : "white",
              color: s.id === screenId ? "white" : "#868C5A",
            }}
            title={s.name}
          >
            {idx + 1}
          </button>
        ))}
      </div>
    </div>
  );
}
