/**
 * Página principal de exportación - índice de todas las opciones disponibles
 */

import { useNavigate } from "react-router";
import { FileImage, Grid3x3, Download, ExternalLink } from "lucide-react";

export function ExportIndex() {
  const navigate = useNavigate();

  const exportOptions = [
    {
      icon: <Grid3x3 size={32} style={{ color: "#4EBA2E" }} />,
      title: "Galería Completa",
      description: "Ver las 6 pantallas juntas en un grid. Ideal para usar con plugins de Figma como html.to.design",
      route: "/screens-gallery",
      badge: "Recomendado",
    },
    {
      icon: <FileImage size={32} style={{ color: "#4EBA2E" }} />,
      title: "Pantallas Individuales",
      description: "Exportar cada pantalla por separado con navegación entre ellas. Perfecto para capturas precisas.",
      route: "/export",
      badge: "Individual",
    },
    {
      icon: <Download size={32} style={{ color: "#4EBA2E" }} />,
      title: "Guía de Exportación",
      description: "Documentación completa con todos los métodos de exportación disponibles y paleta de colores.",
      action: "guide",
      badge: "Docs",
    },
  ];

  const handleAction = (option: typeof exportOptions[0]) => {
    if (option.action === "guide") {
      window.open("/FIGMA_EXPORT_GUIDE.md", "_blank");
    } else if (option.route) {
      navigate(option.route);
    }
  };

  return (
    <div className="min-h-screen p-8" style={{ background: "linear-gradient(160deg, #0A1E16 0%, #1E3D2B 100%)" }}>
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
            <div
              className="w-16 h-16 rounded-full flex items-center justify-center shadow-lg"
              style={{ background: "linear-gradient(135deg, #4EBA2E, #1E3D2B)" }}
            >
              <span className="text-4xl">🐄</span>
            </div>
          </div>
          <h1
            className="text-4xl font-bold mb-3 text-white"
            style={{ fontFamily: "'Poppins', sans-serif" }}
          >
            VacaApp → Figma
          </h1>
          <p className="text-lg" style={{ color: "rgba(255,255,255,0.7)" }}>
            Exporta tus pantallas React a Figma como frames editables
          </p>
        </div>

        {/* Export options */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {exportOptions.map((option) => (
            <button
              key={option.title}
              onClick={() => handleAction(option)}
              className="p-6 rounded-3xl border-2 border-transparent hover:border-[#4EBA2E] transition-all text-left group"
              style={{ background: "white" }}
            >
              <div className="flex items-start justify-between mb-4">
                <div
                  className="w-14 h-14 rounded-2xl flex items-center justify-center"
                  style={{ background: "#E6F1E6" }}
                >
                  {option.icon}
                </div>
                {option.badge && (
                  <div
                    className="px-2 py-1 rounded-full text-xs font-semibold"
                    style={{ background: "#E6F1E6", color: "#1E3D2B" }}
                  >
                    {option.badge}
                  </div>
                )}
              </div>
              <h2
                className="text-xl font-bold mb-2"
                style={{ fontFamily: "'Poppins', sans-serif", color: "#0A1E16" }}
              >
                {option.title}
              </h2>
              <p className="text-sm mb-4" style={{ color: "#868C5A" }}>
                {option.description}
              </p>
              <div
                className="flex items-center gap-2 text-sm font-semibold group-hover:gap-3 transition-all"
                style={{ color: "#4EBA2E" }}
              >
                {option.action === "guide" ? (
                  <>
                    Ver guía <ExternalLink size={16} />
                  </>
                ) : (
                  "Abrir →"
                )}
              </div>
            </button>
          ))}
        </div>

        {/* Quick info */}
        <div className="grid grid-cols-2 gap-4">
          <div className="p-6 rounded-2xl" style={{ background: "rgba(255,255,255,0.1)" }}>
            <h3 className="text-white font-bold mb-3" style={{ fontFamily: "'Poppins', sans-serif" }}>
              📱 Pantallas incluidas
            </h3>
            <ul className="space-y-1 text-sm" style={{ color: "rgba(255,255,255,0.8)" }}>
              <li>1. Splash Screen</li>
              <li>2. Onboarding (3 slides)</li>
              <li>3. Login</li>
              <li>4. Register (3 pasos)</li>
              <li>5. Home con carrusel</li>
              <li>6. Animal Detail</li>
            </ul>
          </div>

          <div className="p-6 rounded-2xl" style={{ background: "rgba(255,255,255,0.1)" }}>
            <h3 className="text-white font-bold mb-3" style={{ fontFamily: "'Poppins', sans-serif" }}>
              🎨 Especificaciones
            </h3>
            <ul className="space-y-1 text-sm" style={{ color: "rgba(255,255,255,0.8)" }}>
              <li>Dimensiones: 390×844px</li>
              <li>Tipografías: Poppins + Inter</li>
              <li>Paleta: 4 colores principales</li>
              <li>Componentes: 40+ elementos UI</li>
            </ul>
          </div>
        </div>

        {/* Color palette preview */}
        <div className="mt-6 p-6 rounded-2xl" style={{ background: "rgba(255,255,255,0.1)" }}>
          <h3 className="text-white font-bold mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>
            Paleta de colores
          </h3>
          <div className="flex gap-4">
            <div className="flex items-center gap-2">
              <div className="w-12 h-12 rounded-xl shadow-lg" style={{ background: "#0A1E16" }} />
              <div>
                <p className="text-xs font-mono text-white">#0A1E16</p>
                <p className="text-xs" style={{ color: "rgba(255,255,255,0.6)" }}>Primary Dark</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-12 h-12 rounded-xl shadow-lg" style={{ background: "#1E3D2B" }} />
              <div>
                <p className="text-xs font-mono text-white">#1E3D2B</p>
                <p className="text-xs" style={{ color: "rgba(255,255,255,0.6)" }}>Primary Mid</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-12 h-12 rounded-xl shadow-lg" style={{ background: "#4EBA2E" }} />
              <div>
                <p className="text-xs font-mono text-white">#4EBA2E</p>
                <p className="text-xs" style={{ color: "rgba(255,255,255,0.6)" }}>Accent Green</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-12 h-12 rounded-xl shadow-lg" style={{ background: "#868C5A" }} />
              <div>
                <p className="text-xs font-mono text-white">#868C5A</p>
                <p className="text-xs" style={{ color: "rgba(255,255,255,0.6)" }}>Muted Gray</p>
              </div>
            </div>
          </div>
        </div>

        {/* Back to app */}
        <div className="mt-8 text-center">
          <button
            onClick={() => navigate("/")}
            className="text-sm"
            style={{ color: "rgba(255,255,255,0.5)" }}
          >
            ← Volver a la app
          </button>
        </div>
      </div>
    </div>
  );
}
