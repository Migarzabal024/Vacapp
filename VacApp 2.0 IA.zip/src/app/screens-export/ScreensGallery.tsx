import { SplashScreen } from "../components/SplashScreen";
import { OnboardingScreen } from "../components/OnboardingScreen";
import { LoginScreen } from "../components/LoginScreen";
import { RegisterScreen } from "../components/RegisterScreen";
import { HomeScreen } from "../components/HomeScreen";
import { AnimalDetailScreen } from "../components/AnimalDetailScreen";

/**
 * Galería de todas las pantallas de VacaApp para exportar a Figma.
 * Cada pantalla está envuelta en un contenedor de 390x844px (iPhone 14 Pro).
 *
 * Para exportar a Figma:
 * 1. Abre esta página en el navegador (ruta: /screens-gallery)
 * 2. Usa el plugin de Figma "html.to.design" o similar
 * 3. Selecciona cada Frame individual para exportar
 *
 * O usa Figma Dev Mode para inspeccionar y copiar los estilos.
 */

const MOBILE_FRAME = {
  width: "390px",
  height: "844px",
  fontFamily: "'Inter', sans-serif",
};

export function ScreensGallery() {
  return (
    <div
      className="min-h-screen p-8"
      style={{ background: "#F0F0F0" }}
    >
      <div className="max-w-7xl mx-auto">
        <h1
          className="text-3xl font-bold mb-8 text-center"
          style={{ fontFamily: "'Poppins', sans-serif", color: "#0A1E16" }}
        >
          VacaApp - Exportación de Pantallas
        </h1>

        <div className="grid grid-cols-3 gap-8">
          {/* Splash Screen */}
          <div className="flex flex-col items-center gap-3">
            <div
              className="relative overflow-hidden bg-white shadow-2xl rounded-lg"
              style={MOBILE_FRAME}
              data-frame-name="01-Splash-Screen"
            >
              <SplashScreen />
            </div>
            <p className="text-sm font-semibold" style={{ color: "#1E3D2B" }}>
              01 - Splash Screen
            </p>
          </div>

          {/* Onboarding Screen */}
          <div className="flex flex-col items-center gap-3">
            <div
              className="relative overflow-hidden bg-white shadow-2xl rounded-lg"
              style={MOBILE_FRAME}
              data-frame-name="02-Onboarding-Screen"
            >
              <OnboardingScreen />
            </div>
            <p className="text-sm font-semibold" style={{ color: "#1E3D2B" }}>
              02 - Onboarding (3 slides)
            </p>
          </div>

          {/* Login Screen */}
          <div className="flex flex-col items-center gap-3">
            <div
              className="relative overflow-hidden bg-white shadow-2xl rounded-lg"
              style={MOBILE_FRAME}
              data-frame-name="03-Login-Screen"
            >
              <LoginScreen />
            </div>
            <p className="text-sm font-semibold" style={{ color: "#1E3D2B" }}>
              03 - Login
            </p>
          </div>

          {/* Register Screen */}
          <div className="flex flex-col items-center gap-3">
            <div
              className="relative overflow-hidden bg-white shadow-2xl rounded-lg"
              style={MOBILE_FRAME}
              data-frame-name="04-Register-Screen"
            >
              <RegisterScreen />
            </div>
            <p className="text-sm font-semibold" style={{ color: "#1E3D2B" }}>
              04 - Registro (3 pasos)
            </p>
          </div>

          {/* Home Screen */}
          <div className="flex flex-col items-center gap-3">
            <div
              className="relative overflow-hidden bg-white shadow-2xl rounded-lg"
              style={MOBILE_FRAME}
              data-frame-name="05-Home-Screen"
            >
              <HomeScreen />
            </div>
            <p className="text-sm font-semibold" style={{ color: "#1E3D2B" }}>
              05 - Home con carrusel
            </p>
          </div>

          {/* Animal Detail Screen */}
          <div className="flex flex-col items-center gap-3">
            <div
              className="relative overflow-hidden bg-white shadow-2xl rounded-lg"
              style={MOBILE_FRAME}
              data-frame-name="06-Animal-Detail-Screen"
            >
              <AnimalDetailScreen />
            </div>
            <p className="text-sm font-semibold" style={{ color: "#1E3D2B" }}>
              06 - Detalle del animal
            </p>
          </div>
        </div>

        <div
          className="mt-12 p-6 rounded-2xl"
          style={{ background: "white", borderLeft: "4px solid #4EBA2E" }}
        >
          <h2
            className="text-xl font-bold mb-3"
            style={{ fontFamily: "'Poppins', sans-serif", color: "#0A1E16" }}
          >
            📋 Instrucciones para exportar a Figma:
          </h2>
          <ol className="list-decimal list-inside space-y-2 text-sm" style={{ color: "#1E3D2B" }}>
            <li>
              <strong>Opción 1 - Plugin html.to.design:</strong> Instala el plugin "html.to.design" en Figma,
              luego copia la URL de esta página y pégala en el plugin. Cada pantalla se importará como un Frame individual.
            </li>
            <li>
              <strong>Opción 2 - Captura de pantalla:</strong> Toma screenshots de cada pantalla (390x844px)
              y luego impórtalas a Figma como imágenes de referencia.
            </li>
            <li>
              <strong>Opción 3 - Figma Dev Mode:</strong> Inspecciona cada pantalla con las herramientas
              de desarrollador de Figma para copiar estilos, medidas y colores exactos.
            </li>
            <li>
              <strong>Opción 4 - Recrear manualmente:</strong> Usa esta galería como referencia visual
              y recrea cada pantalla en Figma frame por frame usando los componentes y estilos definidos.
            </li>
          </ol>

          <div className="mt-4 p-4 rounded-xl" style={{ background: "#E6F1E6" }}>
            <p className="text-sm font-semibold mb-2" style={{ color: "#1E3D2B" }}>
              🎨 Paleta de colores VacaApp:
            </p>
            <div className="flex gap-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg" style={{ background: "#0A1E16" }} />
                <span className="text-xs font-mono">#0A1E16</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg" style={{ background: "#1E3D2B" }} />
                <span className="text-xs font-mono">#1E3D2B</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg" style={{ background: "#4EBA2E" }} />
                <span className="text-xs font-mono">#4EBA2E</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg" style={{ background: "#868C5A" }} />
                <span className="text-xs font-mono">#868C5A</span>
              </div>
            </div>
          </div>

          <div className="mt-4 p-4 rounded-xl" style={{ background: "#E6F1E6" }}>
            <p className="text-sm font-semibold mb-2" style={{ color: "#1E3D2B" }}>
              ✍️ Tipografías:
            </p>
            <ul className="text-xs space-y-1">
              <li><strong>Poppins</strong> (700-800): Títulos y nombres de marca</li>
              <li><strong>Inter</strong> (400-600): Texto del cuerpo y UI</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
