/**
 * Componente wrapper para exportar pantallas individuales a Figma.
 * Cada pantalla se renderiza en un frame de 390x844px con metadata para exportación.
 */

import { ReactNode } from "react";

interface ExportFrameProps {
  children: ReactNode;
  frameName: string;
  description?: string;
}

export function ExportFrame({ children, frameName, description }: ExportFrameProps) {
  return (
    <div
      className="relative overflow-hidden bg-white shadow-2xl"
      style={{
        width: "390px",
        height: "844px",
        fontFamily: "'Inter', sans-serif",
      }}
      data-frame-name={frameName}
      data-frame-description={description}
      data-figma-export="true"
    >
      {children}
    </div>
  );
}

/**
 * Componente para exportar múltiples variantes de una pantalla.
 * Útil para pantallas con múltiples estados (ej: Onboarding slides, Register steps)
 */
interface ExportVariantsProps {
  variants: Array<{
    name: string;
    description?: string;
    component: ReactNode;
  }>;
  baseFrameName: string;
}

export function ExportVariants({ variants, baseFrameName }: ExportVariantsProps) {
  return (
    <div className="flex gap-4 flex-wrap">
      {variants.map((variant, index) => (
        <div key={variant.name} className="flex flex-col items-center gap-2">
          <ExportFrame
            frameName={`${baseFrameName}-${index + 1}-${variant.name}`}
            description={variant.description}
          >
            {variant.component}
          </ExportFrame>
          <p className="text-sm font-semibold" style={{ color: "#1E3D2B" }}>
            {variant.name}
          </p>
        </div>
      ))}
    </div>
  );
}
