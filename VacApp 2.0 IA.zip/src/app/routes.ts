import { createBrowserRouter } from "react-router";
import { SplashScreen } from "./components/SplashScreen";
import { OnboardingScreen } from "./components/OnboardingScreen";
import { LoginScreen } from "./components/LoginScreen";
import { RegisterScreen } from "./components/RegisterScreen";
import { HomeScreen } from "./components/HomeScreen";
import { AnimalDetailScreen } from "./components/AnimalDetailScreen";
import { ScreensGallery } from "./screens-export/ScreensGallery";
import { IndividualScreens } from "./screens-export/IndividualScreens";
import { ExportIndex } from "./screens-export/ExportIndex";

export const router = createBrowserRouter([
  { path: "/", Component: SplashScreen },
  { path: "/onboarding", Component: OnboardingScreen },
  { path: "/login", Component: LoginScreen },
  { path: "/register", Component: RegisterScreen },
  { path: "/home", Component: HomeScreen },
  { path: "/animal/:id", Component: AnimalDetailScreen },
  { path: "/figma-export", Component: ExportIndex },
  { path: "/screens-gallery", Component: ScreensGallery },
  { path: "/export", Component: IndividualScreens },
  { path: "/export/:screenId", Component: IndividualScreens },
]);
